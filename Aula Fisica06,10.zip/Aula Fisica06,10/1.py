def velocidade_media(metros, tempo):
    velocidade = metros / tempo
    return velocidade

metros = float(input("Digite a distancia " ))
tempo = float(input("Digite o tempo " ))

velocidademedia = velocidade_media(metros, tempo)
print("A velocidade média é de", velocidademedia,"m/s")
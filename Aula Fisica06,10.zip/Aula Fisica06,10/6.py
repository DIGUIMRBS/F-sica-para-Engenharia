def tempo_percurso(metros, velocidade):
    tempo = metros / velocidade
    return tempo

metros = float(input("Digite a distancia " ))
velocidade = float(input("Digite a velocidade " ))

tempomedio = tempo_percurso(metros, velocidade)
print("A velocidade média é de", tempomedio,"segundos")
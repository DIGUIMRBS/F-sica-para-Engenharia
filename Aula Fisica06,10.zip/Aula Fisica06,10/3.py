def distancia_total(velocidade, tempo):
    distancia = velocidade * tempo
    return distancia

velocidade = float(input("Digite a velocidade " ))
tempo = float(input("Digite o tempo " ))

distanciatotal = distancia_total(velocidade, tempo)
print("A distancia é de", distanciatotal,"metros")
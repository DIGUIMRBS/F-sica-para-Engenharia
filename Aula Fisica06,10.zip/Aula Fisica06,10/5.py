def distancia_total(velocidade1, velocidade2, tempo1, tempo2):
    distancia1 = velocidade1 * tempo1
    distancia2 = velocidade2 * tempo2  
    dist_total = distancia1 + distancia2
    return dist_total

velocidade1 = float(input("Digite a primeira velocidade"))
velocidade2 = float(input("Digite a segunda velocidade"))
tempo1 = float(input("Digite o primeiro tempo"))
tempo2 = float(input("Digite o segundo tempo"))

dist_total = distancia_total(velocidade1, velocidade2, tempo1, tempo2)
print("A distancia total percorrida pelo carro é de", dist_total, "metros")
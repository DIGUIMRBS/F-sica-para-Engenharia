def perca_comunicacao(velocidade_trem1, velocidade_trem2, distancia_maxima):
    tempo_horas = float(input("tempo em horas")) 
    tempo_segundos = tempo_horas * 3600
    return tempo_segundos

velocidade_trem1 = float(input("Velocidade do Primeiro trem " ))
velocidade_trem2 = float(input("Velocidade do Segundo trem " ))
velocidad_relativa = velocidade_trem1 - velocidade_trem2
distancia_maxima = 10

tempo_de_perca_de_comunicacao = perca_comunicacao(velocidade_trem1, velocidade_trem2, distancia_maxima)
print("Os trens perderam a comunicação apos se passar", tempo_de_perca_de_comunicacao, "segundos")



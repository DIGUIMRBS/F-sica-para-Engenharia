def distancia_total(velocidade, tempo):
    distancia = velocidade * tempo
    return distancia

velocidade = float(input("Digite a velocidade em m/s " ))
tempo = float(input("Digite o tempo em segundos " ))

distanciatotal = distancia_total(velocidade, tempo)
print("A distancia é de", distanciatotal,"metros")
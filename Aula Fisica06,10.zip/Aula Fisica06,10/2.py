def velocidade_conta(distancia, tempo_total, tempo_pneu):
    tempo_andando = tempo_total - tempo_pneu
    velocidade_media = distancia / tempo_andando
    return velocidade_media

distanciatotal = float(input("Digite a distancia total " ))
tempo_total = float(input("Digite o tempo total " ))
tempo_pneu = float(input("Digite o tempo parado por causa do pneu furado " ))

velocidade = velocidade_conta(distanciatotal, tempo_total, tempo_pneu)
print("A velocidade media da viagem foi de", velocidade," m/s")